<!--- Provide a general summary of the feature request in the Title above -->
<!-- You should remove sections that are not related --> 

## Summary
<!--- Summarize what you're wanting to be improved -->


## How the feature functions now
<!--- Tell us how the feature currently functions -->

## How you want the feature to function
<!--- Tell us how you want the feature to function -->

## Other information  (e.g. detailed explanation, stacktraces, related issues, suggestions, links for us to have context, eg. stackoverflow, etc)
<!-- Any other information that you believe will be useful with the implementation of the feature -->
