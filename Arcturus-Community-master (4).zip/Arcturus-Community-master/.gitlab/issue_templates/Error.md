<!--- Provide a general summary of the issue in the Title above -->
<!-- You should remove sections that are not related or use --> 

## Build Information
<!-- Issues will be closed if you don't provide this information, as we may need to replicate it on your exact build -->
Emulator Version:  
Emulator Build (hash):

## What is the error?
```
Include your error here. If you have a thread dump, attach it as a txt file
```

## When does this error occur?
<!--- Tell us when this error occurs -->

## What is the outcome of this error?
<!--- What happens after this error occurs? Does the emulator crash? Does the user disconnect?  -->

## Steps to Reproduce
<!--- Provide a link to a live example, or an unambiguous set of steps to -->
<!--- reproduce this bug. Include code to reproduce, if relevant -->
1.
1.
1.
1.

## Possible Solution
<!--- Not obligatory, but suggest a fix/reason for the bug or make a merge request for your solution -->