<!--- Provide a general summary of the feature request in the Title above -->
<!-- You should remove sections that are not related --> 

## Summary
<!--- Summarize the feature that you want to add -->


## What is the expected behavior of the new feature?
<!--- Tell us how the feature should function -->

## What is the use case of this feature, is it on Habbo.com?
<!-- Explain how you plan on using the feature, whether it is on Habbo.com or has been in the past and if possible a reference such as screenshots of the feature -->

## Other information  (e.g. detailed explanation, stacktraces, related issues, suggestions, links for us to have context, eg. stackoverflow, etc)
<!-- Any other information that you believe will be useful with the implementation of the feature -->