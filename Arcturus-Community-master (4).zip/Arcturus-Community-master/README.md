Hæbbo's edit av Arcuturus Morningstar
