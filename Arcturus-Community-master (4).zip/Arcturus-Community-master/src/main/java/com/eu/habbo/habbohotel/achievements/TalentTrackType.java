package com.eu.habbo.habbohotel.achievements;

public enum TalentTrackType {

    CITIZENSHIP,


    HELPER
}