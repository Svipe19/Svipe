package com.eu.habbo.habbohotel.items.interactions.wired;

public interface WiredTriggerReset {
    void resetTimer();
}
