package com.eu.habbo.habbohotel.catalog;

public enum CatalogPageType {

    NORMAL,


    BUILDER
}
