package com.eu.habbo.habbohotel.guilds;

public enum GuildPartType {

    BASE,


    SYMBOL,


    BASE_COLOR,
    SYMBOL_COLOR,
    BACKGROUND_COLOR
}
