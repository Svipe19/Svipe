package com.eu.habbo.core;

public interface Disposable {
    void dispose();

    boolean disposed();
}
