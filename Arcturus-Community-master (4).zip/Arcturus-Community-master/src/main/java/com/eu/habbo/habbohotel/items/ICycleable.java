package com.eu.habbo.habbohotel.items;

import com.eu.habbo.habbohotel.rooms.Room;

public interface ICycleable {
    void cycle(Room room);
}
