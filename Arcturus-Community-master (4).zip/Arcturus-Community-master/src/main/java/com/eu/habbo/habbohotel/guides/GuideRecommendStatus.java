package com.eu.habbo.habbohotel.guides;

public enum GuideRecommendStatus {
    UNKNOWN,
    YES,
    NO
}
