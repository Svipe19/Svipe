package com.eu.habbo.habbohotel.games;

public enum GameState {
    IDLE,
    RUNNING,
    PAUSED
}