package com.eu.habbo.habbohotel.achievements;

public enum AchievementCategories {

    IDENTITY,


    EXPLORE,


    MUSIC,


    SOCIAL,


    GAMES,


    ROOM_BUILDER,


    PETS,


    TOOLS,


    OTHER,


    TEST,


    INVISIBLE,


    EVENTS
}
