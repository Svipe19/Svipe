package com.eu.habbo.habbohotel.games.tag;

import com.eu.habbo.habbohotel.games.GamePlayer;
import com.eu.habbo.habbohotel.games.GameTeamColors;
import com.eu.habbo.habbohotel.users.Habbo;

public class TagGamePlayer extends GamePlayer {

    public TagGamePlayer(Habbo habbo, GameTeamColors teamColor) {
        super(habbo, teamColor);
    }
}