INSERT INTO `emulator_texts`(`key`, `value`) VALUES ('commands.generic.cmd_commands.text', 'Your Commands');
INSERT INTO `emulator_texts`(`key`, `value`) VALUES ('commands.keys.cmd_stand', 'stand');
