INSERT INTO `emulator_texts`(`key`, `value`) VALUES ('commands.error.cmd_badge.unknown_user', 'Failed to find the given user.');
