INSERT INTO `emulator_settings`(`key`, `value`) VALUES ('hotel.room.stickies.max', '200');

INSERT INTO `emulator_settings`(`key`, `value`) VALUES ('retro.style.homeroom', '1');