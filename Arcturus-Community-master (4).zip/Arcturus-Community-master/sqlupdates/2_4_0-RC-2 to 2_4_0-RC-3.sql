-- Recycler value fix
INSERT INTO `emulator_settings` (`key`, `value`) VALUES ('recycler.value', '8');
