INSERT INTO `emulator_settings`(`key`, `value`) VALUES ('hotel.room.floorplan.check.enabled', '1');
