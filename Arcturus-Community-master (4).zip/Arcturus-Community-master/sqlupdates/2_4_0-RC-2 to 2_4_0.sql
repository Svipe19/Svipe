-- Adds config value for max amount of people to move per roller. Default is like habbo.
INSERT INTO `emulator_settings`(`key`, `value`) VALUES ('hotel.room.rollers.roll_avatars.max', '1');
INSERT INTO `emulator_settings`(`key`, `value`) VALUES ('hotel.nux.gifts.enabled', '0');
